- simple lambda function
- sends mysql commands to a mysql server in AWS RDS
- meant to be accessed via API Gateway
- will add more features, probably


# Local testing

## Prereqs
- Create /etc/basic-lambda-mysql-client.env
  - You can use basic-lambda-mysql-client.example.env as an example
- Run "npm test"